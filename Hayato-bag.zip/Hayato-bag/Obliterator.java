interface Obliterator {

  boolean hasNext();

  Node next();

}
